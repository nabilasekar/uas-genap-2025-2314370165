<?php
session_start();
include 'koneksi.php';

if ($_SESSION['password'] == '') {
    header("Location: login.php");
    exit;
}

// Aktifkan pesan error
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Eksekusi DELETE
$hapus = mysqli_query($conn, "DELETE FROM keluar");

if ($hapus) {
    echo "<script>alert('Semua data berhasil dihapus!');window.location='input.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus data!');window.location='input.php';</script>";
}
?>
