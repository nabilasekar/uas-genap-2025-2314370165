<?php

  $conn = mysqli_connect('localhost','root','','databarang') or die($conn);

?>
