<?php
session_start();
include 'koneksi.php';

// Cek sesi login
if ($_SESSION['password'] == '') {
    header("Location: login.php");
    exit;
}

// Eksekusi penghapusan data
$hapus = mysqli_query($conn, "DELETE FROM keluar");

if ($hapus) {
    echo "<script>
        alert('Semua data berhasil dihapus!');
        window.location.href = 'input.php';
    </script>";
} else {
    echo "<script>
        alert('Gagal menghapus data!');
        window.location.href = 'input.php';
    </script>";
}
?>
