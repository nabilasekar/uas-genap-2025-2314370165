<?php
include 'koneksi.php';

// Pastikan hanya admin yang bisa akses
session_start();
if ($_SESSION['password'] == '') {
    header("location:login.php");
    exit;
}

// Eksekusi penghapusan
$query1 = mysqli_query($conn, "DELETE FROM masuk");
$query2 = mysqli_query($conn, "DELETE FROM modal");

if ($query1 && $query2) {
    echo "<script>
        alert('Semua data berhasil dihapus!');
        window.location.href = 'input.php';
    </script>";
} else {
    echo "<script>
        alert('Gagal menghapus data!');
        window.location.href = 'input.php';
    </script>";
}
?>
